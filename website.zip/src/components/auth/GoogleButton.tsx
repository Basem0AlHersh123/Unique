"use client";

import { useState } from "react";
import { useGoogleLogin } from "@react-oauth/google";
import { useRouter } from "next/navigation";
import api from "@/lib/api";
import { useLanguage } from "@/lib/i18n/LanguageProvider";

interface GoogleButtonProps {
  mode?: "login" | "register";
  onError?: (msg: string) => void;
}

const googleConfigured = !!process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;

export function GoogleButton({ mode = "login", onError }: GoogleButtonProps) {
  const router = useRouter();
  const { t, isRTL } = useLanguage();
  const [isLoading, setIsLoading] = useState(false);

  if (!googleConfigured) return null;

  const login = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      setIsLoading(true);
      try {
        let userInfo: { sub: string; email: string; name: string; picture?: string } | null = null;
        try {
          const res = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
            headers: { Authorization: `Bearer ${tokenResponse.access_token}` },
          });
          if (res.ok) {
            userInfo = await res.json();
          }
        } catch {
          // fallback to token-only
        }

        const res = await api.post("/api/auth/google", {
          accessToken: tokenResponse.access_token,
          userInfo,
        });

        const result = res.data;
        if (result.success) {
          localStorage.setItem("accessToken", result.data.accessToken);
          router.push("/dashboard");
        } else {
          onError?.(result.error || "فشل تسجيل الدخول");
        }
      } catch (err: unknown) {
        const msg =
          err instanceof Error ? err.message : "حدث خطأ في تسجيل الدخول";
        onError?.(msg);
      } finally {
        setIsLoading(false);
      }
    },
    onError: () => {
      onError?.(isRTL ? "فشل تسجيل الدخول بواسطة Google" : "Google sign-in failed");
    },
  });

  return (
    <button
      type="button"
      onClick={() => login()}
      disabled={isLoading}
      className="flex items-center justify-center gap-3 w-full px-6 py-2.5 text-sm font-medium rounded-xl border border-border bg-surface text-text-secondary hover:text-text-primary hover:border-primary/30 hover:bg-surface-hover transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
    >
      {isLoading ? (
        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      ) : (
        <svg className="w-5 h-5" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
        </svg>
      )}
      {isLoading
        ? (isRTL ? "جاري التحميل..." : "Loading...")
        : mode === "login"
        ? (isRTL ? "تسجيل الدخول بواسطة Google" : "Sign in with Google")
        : (isRTL ? "التسجيل بواسطة Google" : "Sign up with Google")}
    </button>
  );
}
