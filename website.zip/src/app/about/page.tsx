"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/Button";
import { Navbar } from "@/components/layout/Navbar";
import { useLanguage } from "@/lib/i18n/LanguageProvider";
import { useAnimatedCounter } from "@/lib/useAnimatedCounter";
import { apiFetch } from "@/lib/api";
import {
  ArrowLeft,
  Play,
  Star,
  Target,
  Shield,
  Heart,
  Users,
  Lightbulb,
  Sparkles,
  CheckCircle,
  Award,
  Quote,
} from "lucide-react";

function AnimatedStat({
  icon: Icon,
  label,
  value,
  suffix,
}: {
  icon: React.ElementType;
  label: string;
  value: number;
  suffix: string;
}) {
  const { count, ref } = useAnimatedCounter(value);
  return (
    <div
      className="flex flex-col items-center gap-2 group slide-up"
      ref={ref}
      style={{ animationDelay: `${Math.random() * 0.2}s` }}
    >
      <div className="p-3 rounded-2xl bg-primary/10 group-hover:bg-primary/20 transition-all duration-300">
        <Icon className="w-7 h-7 text-primary" />
      </div>
      <span className="text-3xl sm:text-4xl font-bold gradient-text tabular-nums">
        {count}
        {suffix}
      </span>
      <span className="text-sm text-text-secondary font-medium">{label}</span>
    </div>
  );
}

interface AboutVideo {
  name: string;
  role: string;
  title: string;
  desc: string;
  avatar?: string;
  videoUrl?: string;
}

export default function AboutPage() {
  const { t, isRTL } = useLanguage();
  const [aboutVideos, setAboutVideos] = useState<AboutVideo[]>([]);
  const [aboutHero, setAboutHero] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<{ items: AboutVideo[] }>("/api/site-content?section=about-videos")
      .then((res) => {
        if (res.success && res.data?.items) setAboutVideos(res.data.items);
      })
      .catch(() => {});
    apiFetch<{ imageUrl?: string }>("/api/site-content?section=about-hero")
      .then((res) => {
        if (res.success && res.data?.imageUrl) setAboutHero(res.data.imageUrl);
      })
      .catch(() => {});
  }, []);

  const values = [
    {
      icon: Target,
      title: t("about.values.excellence"),
      desc: t("about.values.excellence_desc"),
    },
    {
      icon: Shield,
      title: t("about.values.credibility"),
      desc: t("about.values.credibility_desc"),
    },
    {
      icon: Heart,
      title: t("about.values.care"),
      desc: t("about.values.care_desc"),
    },
    {
      icon: Lightbulb,
      title: t("about.values.innovation"),
      desc: t("about.values.innovation_desc"),
    },
  ];

  const videoTestimonials = aboutVideos.length > 0 ? aboutVideos : [
    {
      name: t("about.videos.1.name"),
      role: t("about.videos.1.role"),
      avatar: t("about.videos.1.name")[0],
      title: t("about.videos.1.title"),
      desc: t("about.videos.1.desc"),
    },
    {
      name: t("about.videos.2.name"),
      role: t("about.videos.2.role"),
      avatar: t("about.videos.2.name")[0],
      title: t("about.videos.2.title"),
      desc: t("about.videos.2.desc"),
    },
    {
      name: t("about.videos.3.name"),
      role: t("about.videos.3.role"),
      avatar: t("about.videos.3.name")[0],
      title: t("about.videos.3.title"),
      desc: t("about.videos.3.desc"),
    },
  ];

  const teamMembers = [
    { name: t("about.team.member1"), role: t("about.team.member1_role"), emoji: "👨‍🔬" },
    { name: t("about.team.member2"), role: t("about.team.member2_role"), emoji: "👩‍🔬" },
    { name: t("about.team.member3"), role: t("about.team.member3_role"), emoji: "👨‍💻" },
    { name: t("about.team.member4"), role: t("about.team.member4_role"), emoji: "👩‍💼" },
  ];

  return (
    <main className="flex-1 flex flex-col">
      <Navbar />

      {/* Hero - Enhanced */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 border-b border-border/20">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-secondary/10 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-20 text-center relative">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 border border-primary/20 slide-up">
            <Sparkles className="w-4 h-4" />
            {t("about.badge")}
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-text-primary mb-4 slide-up" style={{ animationDelay: "0.05s" }}>
            {t("about.title")}
          </h1>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto leading-relaxed slide-up" style={{ animationDelay: "0.1s" }}>
            {t("about.desc")}
          </p>
          {aboutHero && (
            <div className="mt-8 max-w-3xl mx-auto slide-up" style={{ animationDelay: "0.15s" }}>
              <div className="relative rounded-2xl overflow-hidden shadow-xl border border-border/50">
                <Image
                  src={aboutHero}
                  alt={t("about.title")}
                  width={800}
                  height={400}
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent" />
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Mission - Enhanced */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="slide-up">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary mb-4">
                {t("about.mission.title")}
              </h2>
              <p className="text-text-secondary leading-relaxed mb-6">
                {t("about.mission.desc")}
              </p>
              <div className="space-y-3">
                {[
                  t("about.mission.point1"),
                  t("about.mission.point2"),
                  t("about.mission.point3"),
                  t("about.mission.point4"),
                ].map((item, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-2 text-sm text-text-secondary slide-up"
                    style={{ animationDelay: `${i * 0.05}s` }}
                  >
                    <CheckCircle className="w-4 h-4 text-teal shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6 p-8 bg-surface rounded-3xl border border-border shadow-xl slide-up" style={{ animationDelay: "0.1s" }}>
              <AnimatedStat
                icon={Users}
                label={t("about.stat.students")}
                value={5000}
                suffix="+"
              />
              <AnimatedStat
                icon={Play}
                label={t("about.stat.videos")}
                value={200}
                suffix="+"
              />
              <AnimatedStat
                icon={Award}
                label={t("about.stat.success")}
                value={85}
                suffix="%"
              />
              <AnimatedStat
                icon={Star}
                label={t("about.stat.rating")}
                value={4.8}
                suffix=""
              />
            </div>
          </div>
        </div>
      </section>

      {/* Video Testimonials - Enhanced */}
      <section className="py-16 sm:py-20 bg-surface/50 border-y border-border/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4 border border-primary/20">
              <Play className="w-4 h-4" />
              {t("about.videos.badge")}
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">
              {t("about.videos.title")}
            </h2>
            <p className="text-text-secondary mt-3 max-w-xl mx-auto">
              {t("about.videos.subtitle")}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {videoTestimonials.map((item, i) => (
              <div
                key={i}
                className="group bg-surface border border-border rounded-2xl overflow-hidden hover:shadow-2xl hover:shadow-primary/10 hover:-translate-y-2 transition-all duration-300 slide-up"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                {item.videoUrl ? (
                  (() => {
                    const youtubeMatch =
                      /(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/.exec(
                        item.videoUrl
                      );
                    if (youtubeMatch) {
                      return (
                        <div className="aspect-video bg-gradient-to-br from-primary/20 to-secondary/20 relative">
                          <iframe
                            src={`https://www.youtube.com/embed/${youtubeMatch[1]}`}
                            className="absolute inset-0 w-full h-full"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                          />
                        </div>
                      );
                    }
                    return (
                      <div className="aspect-video bg-gradient-to-br from-primary/20 to-secondary/20 relative">
                        <video
                          src={item.videoUrl}
                          className="absolute inset-0 w-full h-full object-contain bg-black/20"
                          controls
                          playsInline
                        />
                      </div>
                    );
                  })()
                ) : (
                  <div className="aspect-video bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center relative">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="w-16 h-16 rounded-full bg-white/90 shadow-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 z-10">
                      <Play className="w-7 h-7 text-primary mr-0.5" />
                    </div>
                  </div>
                )}
                <div className="p-5">
                  <h3 className="font-bold text-text-primary mb-1">{item.title}</h3>
                  <p className="text-sm text-text-secondary mb-4 leading-relaxed">
                    "{item.desc}"
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center text-white text-sm font-bold shadow-md">
                      {item.avatar}
                    </div>
                    <div>
                      <p className="font-semibold text-text-primary text-sm">
                        {item.name}
                      </p>
                      <p className="text-xs text-text-muted">{item.role}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values - Enhanced */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-secondary/10 text-secondary text-sm font-medium mb-4 border border-secondary/20">
              <Heart className="w-4 h-4" />
              {t("about.values.badge")}
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary">
              {t("about.values.title")}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => {
              const Icon = v.icon;
              return (
                <div
                  key={i}
                  className="text-center bg-surface border border-border rounded-2xl p-8 hover:shadow-2xl hover:shadow-primary/10 hover:-translate-y-2 transition-all duration-300 slide-up"
                  style={{ animationDelay: `${i * 0.05}s` }}
                >
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                  <h3 className="text-lg font-bold text-text-primary mb-2">
                    {v.title}
                  </h3>
                  <p className="text-sm text-text-secondary leading-relaxed">
                    {v.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Team - Enhanced */}
      <section className="py-16 sm:py-20 bg-gradient-to-br from-primary/5 via-transparent to-secondary/5 border-y border-border/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-teal/10 text-teal text-sm font-medium mb-4 border border-teal/20 slide-up">
            <Users className="w-4 h-4" />
            {t("about.team.badge")}
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-text-primary mb-4 slide-up" style={{ animationDelay: "0.05s" }}>
            {t("about.team.title")}
          </h2>
          <p className="text-text-secondary max-w-2xl mx-auto mb-10 leading-relaxed slide-up" style={{ animationDelay: "0.1s" }}>
            {t("about.team.desc")}
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {teamMembers.map((person, i) => (
              <div
                key={i}
                className="bg-surface border border-border rounded-2xl p-6 hover:shadow-2xl hover:shadow-primary/10 hover:-translate-y-2 transition-all duration-300 slide-up"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <div className="text-5xl mb-3">{person.emoji}</div>
                <p className="font-bold text-text-primary text-sm">{person.name}</p>
                <p className="text-xs text-text-muted mt-1">{person.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA - Enhanced */}
      <section className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary via-primary-dark to-secondary p-8 sm:p-12 text-center slide-up">
            <div className="absolute inset-0">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full blur-3xl" />
            </div>
            <div className="relative">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
                {t("about.cta.title")}
              </h2>
              <p className="text-white/80 max-w-xl mx-auto mb-8 text-lg">
                {t("about.cta.desc")}
              </p>
              <Link href="/auth/register">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-warning to-accent text-white hover:from-warning/90 hover:to-accent/90 shadow-2xl shadow-warning/30 hover:scale-105 transition-all duration-300"
                >
                  <ArrowLeft className={`w-5 h-5 ${isRTL ? "" : "rotate-180"}`} />
                  {t("about.cta.button")}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer - Enhanced */}
      <footer className="border-t border-border/20 py-8 bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Image
              src="/logo.svg"
              alt="UNIQUE"
              width={28}
              height={28}
              className="shrink-0"
            />
            <span className="text-lg font-bold gradient-text">
              {t("common.brand")}
            </span>
          </div>
          <div className="flex items-center gap-4 text-sm text-text-muted">
            <Link href="/" className="hover:text-primary transition-colors">
              {t("about.footer_home")}
            </Link>
            <Link href="/about" className="hover:text-primary transition-colors">
              {t("nav.about")}
            </Link>
            <Link href="/contact" className="hover:text-primary transition-colors">
              {t("nav.contact")}
            </Link>
            <Link href="/colleges" className="hover:text-primary transition-colors">
              {t("nav.colleges")}
            </Link>
          </div>
          <p className="text-sm text-text-muted">
            {t("footer.copyright")} {new Date().getFullYear()} {t("common.brand")}
          </p>
        </div>
      </footer>
    </main>
  );
}