"use client";

import { ButtonHTMLAttributes, ReactNode } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger";
  isLoading?: boolean;
  children: ReactNode;
}

/**
 * Matches blueprint Section 5 component spec:
 * - Primary: filled purple, scales up slightly + shadow on hover
 * - Secondary: outlined purple, fills lightly on hover
 * - Danger: filled red, only for delete/logout actions
 */
export function Button({
  variant = "primary",
  isLoading = false,
  disabled,
  children,
  className = "",
  ...rest
}: ButtonProps) {
  const base =
    "px-6 py-3 rounded-lg font-semibold text-sm transition-all duration-150 ease-out disabled:opacity-50 disabled:cursor-not-allowed";

  const variants: Record<string, string> = {
    primary:
      "bg-primary text-white hover:scale-[1.02] hover:shadow-lg active:scale-[0.98]",
    secondary:
      "bg-transparent border-2 border-primary text-primary hover:bg-surface-hover",
    danger: "bg-danger text-white hover:scale-[1.02] hover:shadow-lg",
  };

  return (
    <button
      disabled={disabled || isLoading}
      className={`${base} ${variants[variant]} ${className}`}
      {...rest}
    >
      {isLoading ? "..." : children}
    </button>
  );
}
