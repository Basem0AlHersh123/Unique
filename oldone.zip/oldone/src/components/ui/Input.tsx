import { InputHTMLAttributes, forwardRef } from "react";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

/**
 * forwardRef is required here because react-hook-form needs a direct
 * reference to the actual <input> DOM element to register and track it.
 * Without forwardRef, react-hook-form can't see this component at all.
 */
export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, className = "", ...rest }, ref) => {
    return (
      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-medium text-text-secondary">
          {label}
        </label>
        <input
          ref={ref}
          className={`w-full px-4 py-3 rounded-lg bg-surface border-[1.5px] text-text-primary
            placeholder:text-text-muted outline-none transition-colors duration-150
            ${error ? "border-danger" : "border-border focus:border-primary"}
            ${className}`}
          {...rest}
        />
        {error && <p className="text-sm text-danger">{error}</p>}
      </div>
    );
  }
);

Input.displayName = "Input";
