import { NextRequest,NextResponse } from "next/server";
import { verifyAccessToken } from "./auth";


export async function requireAdmin(req:NextRequest){
    const authHeader= req.headers.get("authorization");
    if(!authHeader?.startsWith("Bearer ")){
        return NextResponse.json(
            {success:false,error:"غير مصرح لك بهذا الاجراء"},
            {status:401}
        )
    }
    const token = authHeader.slice("Bearer ".length);
    try {
        const payload= verifyAccessToken(token);
        if(payload.role!=="admin"){
            return NextResponse.json(
                {success:false,error:"هذا الاجراء مخصص للمدير فقط"},
                {status:403}
            )
        }
        return null; 
    } catch (error) {
        console.log(error)
        return NextResponse.json(
            {success:false,error:"الجلسة منتهية يرجى تسجيل الدخول مرة اخرى"},
            {status:401}
        )
    }
}