/**
 * hCaptcha gives the browser a token after the user solves the challenge.
 * That token alone proves NOTHING by itself — anyone could fake a string
 * client-side. We must call hCaptcha's verify endpoint from OUR server
 * with OUR secret key to confirm the token is real and unused.
 * This is why this function lives in lib/ and only ever runs server-side.
 */
export async function verifyHCaptcha(token: string): Promise<boolean> {
  const secret = process.env.HCAPTCHA_SECRET_KEY;

  if (!secret) {
    throw new Error("HCAPTCHA_SECRET_KEY is not set");
  }

  const response = await fetch("https://hcaptcha.com/siteverify", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ secret, response: token }),
  });

  const data = await response.json();
  return data.success === true;
}