"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Turnstile } from "@marsidev/react-turnstile";
import { registerSchema, type RegisterInput } from "@/lib/validation/auth";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";

export default function RegisterPage() {
  const router = useRouter();
  const [serverError, setServerError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    resetField,
    formState: { errors },
  } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: { hcaptchaToken: "" },
  });

  // Called by the Turnstile widget once it silently (usually) confirms
  // the visitor is human. We push the resulting token into the form so
  // it travels along with the rest of the data when the form submits.
  function onCaptchaSuccess(token: string) {
    setValue("hcaptchaToken", token);
  }

  async function onSubmit(data: RegisterInput) {
    setServerError(null);
    setIsSubmitting(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await res.json();

      if (!result.success) {
        setServerError(result.error);
        resetField("hcaptchaToken");
        setIsSubmitting(false);
        return;
      }

      // Store the access token for now (Week 1 keeps this simple —
      // we'll move to a proper auth context/store in a later step).
      localStorage.setItem("accessToken", result.data.accessToken);
      router.push("/dashboard");
    } catch {
      setServerError("تعذر الاتصال بالخادم، تحقق من اتصالك بالإنترنت");
      setIsSubmitting(false);
    }
  }

  return (
    <main className="flex-1 flex items-center justify-center px-4 py-12 bg-background">
      <div className="w-full max-w-md bg-surface rounded-2xl shadow-lg p-8 border border-border">
        <h1 className="text-2xl font-bold text-text-primary mb-1">
          إنشاء حساب جديد
        </h1>
        <p className="text-text-secondary text-sm mb-6">
          ابدأ رحلتك نحو اختبار القبول بثقة
        </p>

        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
          <Input
            label="الاسم الكامل"
            placeholder="مثال: أحمد محمد"
            {...register("name")}
            error={errors.name?.message}
          />

          <Input
            label="البريد الإلكتروني"
            type="email"
            placeholder="example@email.com"
            {...register("email")}
            error={errors.email?.message}
          />

          <Input
            label="كلمة المرور"
            type="password"
            placeholder="8 أحرف على الأقل"
            {...register("password")}
            error={errors.password?.message}
          />

          <div className="flex justify-center py-2">
            <Turnstile
              siteKey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY as string}
              onSuccess={onCaptchaSuccess}
            />
          </div>
          {errors.hcaptchaToken && (
            <p className="text-sm text-danger text-center">
              {errors.hcaptchaToken.message}
            </p>
          )}

          {serverError && (
            <div className="bg-danger/10 border border-danger rounded-lg px-4 py-3 text-danger text-sm">
              {serverError}
            </div>
          )}

          <Button type="submit" isLoading={isSubmitting} className="mt-2">
            تسجيل
          </Button>
        </form>

        <p className="text-center text-sm text-text-secondary mt-6">
          لديك حساب بالفعل؟{" "}
          <a href="/auth/login" className="text-primary font-medium">
            تسجيل الدخول
          </a>
        </p>
      </div>
    </main>
  );
}
