import { NextRequest,NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { College } from "@/models/College";
import { z } from "zod";
import { requireAdmin } from "@/lib/requireAdmin";

export const createCollegeSchema = z.object({
  name: z
    .string()
    .min(2, "الاسم الكلية قصير جدا ")
    .max(100, "الاسم طويل جداً"),
  slug: z.string().regex(/^[a-z0-9]+$/,"الرابط غير صالح"),
  comingSoon:z.boolean().optional(),
  icon:z.string().optional(),
  color:z.string().optional()
});
export async function POST(req:NextRequest){
    const adminCheck=requireAdmin(req)
    if(adminCheck)return adminCheck;
    try {
        const body= await req.json();
        const parsed= createCollegeSchema.safeParse(body);
        if(!parsed.success){
            return NextResponse.json(
            {success:false,error:parsed.error.issues[0].message}
            ,{status:400}
        )
    }
    await connectDB();
    const existing= await College.findOne({slug:parsed.data.slug});
    if(existing){
            return NextResponse.json(
            {success:false,error:"يوجد رابط مستخدم للكلية بالفعل"}
            ,{status:409}
        )
        }
        const college= College.create(parsed.data);
        return NextResponse.json({
            success:true,data:college
        },
    {status:201});
    } catch (error) {
        console.log(error);
        return NextResponse.json(
            {success:false,error:"حدث خطاء في الخادم"}
            ,{status:500}
        )
        
    }
}
export async function GET(){
    try {
        await connectDB();
        const colleges= await College.find().sort({craeteAt:1})
        return NextResponse.json({
            success:true,data:colleges
        });
    } catch (error) {
        console.log(error)
        return NextResponse.json(
            {success:false,error:"حدث خطاء في الخادم"}
            ,{status:500}
        )
        
    }
}
