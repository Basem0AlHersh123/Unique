"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import HCaptcha from "@hcaptcha/react-hcaptcha";
import { loginSchema, type LoginInput } from "@/lib/validation/auth";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";

export default function LoginPage() {
  const router = useRouter();
  const captchaRef = useRef<HCaptcha>(null);
  const [serverError, setServerError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: { hcaptchaToken: "" },
  });

  function onCaptchaVerify(token: string) {
    setValue("hcaptchaToken", token);
  }

  async function onSubmit(data: LoginInput) {
    setServerError(null);
    setIsSubmitting(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await res.json();

      if (!result.success) {
        setServerError(result.error);
        captchaRef.current?.resetCaptcha();
        setIsSubmitting(false);
        return;
      }
      localStorage.setItem("accessToken", result.data.accessToken);
      router.push("/dashboard");
    } catch {
      setServerError("تعذر الاتصال بالخادم، تحقق من اتصالك بالإنترنت");
      setIsSubmitting(false);
    }
  }

  return (
    <main className="flex-1 flex items-center justify-center px-4 py-12 bg-background">
      <div className="w-full max-w-md bg-surface rounded-2xl shadow-lg p-8 border border-border">
        <h1 className="text-2xl font-bold text-text-primary mb-1">
          تسجيل الدخول
        </h1>
        <p className="text-text-secondary text-sm mb-6">
          أهلاً بعودتك! استمر في رحلتك التعليمية
        </p>

        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
          <Input
            label="البريد الإلكتروني"
            type="email"
            placeholder="example@email.com"
            {...register("email")}
            error={errors.email?.message}
          />

          <Input
            label="كلمة المرور"
            type="password"
            placeholder="••••••••"
            {...register("password")}
            error={errors.password?.message}
          />

          <div className="flex justify-center py-2">
            <HCaptcha
              ref={captchaRef}
              sitekey={process.env.NEXT_PUBLIC_HCAPTCHA_SITE_KEY as string}
              onVerify={onCaptchaVerify}
            />
          </div>
          {errors.hcaptchaToken && (
            <p className="text-sm text-danger text-center">
              {errors.hcaptchaToken.message}
            </p>
          )}

          {serverError && (
            <div className="bg-danger/10 border border-danger rounded-lg px-4 py-3 text-danger text-sm">
              {serverError}
            </div>
          )}

          <Button type="submit" isLoading={isSubmitting} className="mt-2">
            تسجيل الدخول
          </Button>
        </form>

        <p className="text-center text-sm text-text-secondary mt-6">
          ليس لديك حساب؟{" "}
          <a href="/auth/register" className="text-primary font-medium">
            إنشاء حساب جديد
          </a>
        </p>
      </div>
    </main>
  );
}
