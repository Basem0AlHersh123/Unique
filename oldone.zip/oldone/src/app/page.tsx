import Link from "next/link";
import { Button } from "@/components/ui/Button";

/**
 * Placeholder homepage for Week 1. The real landing page (hero, features,
 * how-it-works, testimonials) is a Week 8 polish task per the build plan —
 * right now we just need auth working end-to-end.
 */
export default function Home() {
  return (
    <main className="flex-1 flex flex-col items-center justify-center gap-6 px-4 text-center bg-background">
      <h1 className="text-4xl font-bold text-primary">UNIQUE</h1>
      <p className="text-text-secondary max-w-md">
        منصة التعلم الذكي للاستعداد لاختبارات القبول الجامعي
      </p>
      <div className="flex gap-4">
        <Link href="/auth/register">
          <Button variant="primary">ابدأ الآن</Button>
        </Link>
        <Link href="/auth/login">
          <Button variant="secondary">تسجيل الدخول</Button>
        </Link>
      </div>
    </main>
  );
}
