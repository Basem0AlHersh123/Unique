/**
 * Placeholder dashboard. Real version (streak, progress, learning map)
 * comes in Week 7 per the build plan. For now this just confirms that
 * registration/login successfully redirects somewhere real.
 */
export default function DashboardPage() {
  return (
    <main className="flex-1 flex items-center justify-center bg-background">
      <p className="text-text-primary text-xl">
        مرحباً بك! لوحة التحكم قيد الإنشاء 🚧
      </p>
    </main>
  );
}
