import mongoose, { Schema, model, models, type Document } from "mongoose";

/**
 * This interface gives us TypeScript autocomplete and type-checking
 * everywhere we use a User document in our code.
 */
export interface ISubject extends Document {
  name: string;
  slug: string;
  collegeId: mongoose.Types.ObjectId;
  isShared:boolean;
  topics: mongoose.Types.ObjectId[];
  createdAt: Date;
  updatedAt: Date;
}

const SubjectSchema = new Schema<ISubject>(
  {
    name: {
      type: String,
      required: [true, "الاسم المادة مطلوب"],
      trim: true,
      minlength: 2,
      maxlength: 100,
    },
    collegeId:{
        type:Schema.Types.ObjectId,
        ref:"College",
        required:true     
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      // Basic email shape check at the DB layer too — defense in depth,
      // even though Zod already validates this before it gets here.
      match: [/^[a-z0-9]+$/, "الرابط يحتوي فقط على ارقام حروف انجليزي صغيرة وارقام وشرطات فقط"],
    },
    topics: [
        {
            type:Schema.Types.ObjectId,
            ref:"Topic"
        }
    ],
    isShared:{
        type:Boolean,
        default:false
    },
  },
  {
    timestamps: true, // adds createdAt + updatedAt automatically
  }
);

// Prevents "Cannot overwrite model" errors during Next.js hot-reload —
// re-use the existing compiled model if it already exists.
export const Subject = models.Subject || model<ISubject>("Subject", SubjectSchema);
