import mongoose, { Schema, model, models, type Document } from "mongoose";

export interface ICollege extends Document {
  name: string;
  slug: string;
  subjects: mongoose.Types.ObjectId[];
  isActive: boolean;
  comingSoon:boolean;
  icon:string;
  color:string;
  createdAt: Date;
  updatedAt: Date;
}

const CollegeSchema = new Schema<ICollege>(
  {
    name: {
      type: String,
      required: [true, "اسم الكلية مطلوب"],
      trim: true,
      minlength: 2,
      maxlength: 100,
    },
    slug: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      // Basic email shape check at the DB layer too — defense in depth,
      // even though Zod already validates this before it gets here.
      match: [/^[a-z0-9]+$/, "الرابط يحتوي فقط على ارقام حروف انجليزي صغيرة وارقام وشرطات فقط"],
    },
    subjects: [
        {
            type:Schema.Types.ObjectId,
            ref:"Subject"
        }
    ],
    isActive:{
        type:Boolean,
        default:false
    },
    comingSoon:{
        type:Boolean,
        default:false
    },
      icon:{
        type:String,
        default:"GraduationCap"
      },
  color:{
    type:String,
    default:"#6C63FF"
  },
  },
  {
    timestamps: true, // adds createdAt + updatedAt automatically
  }
);
export const College = models.College || model<ICollege>("College", CollegeSchema);
