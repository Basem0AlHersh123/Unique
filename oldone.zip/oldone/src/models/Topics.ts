import mongoose, { Schema, model, models, type Document } from "mongoose";
export interface IVocabularyItem {
    word:string;
    definition:string;
}
export interface ITopic extends Document {
  title: string;
  slug: string;
  subjectId: mongoose.Types.ObjectId;
  videoURL:string;
  aiExplanation?:string;
  keyPoints:string[];
  vocabulary:IVocabularyItem[];
  order:number;
  isFree:boolean;
  isPublished:boolean;
  difficulty:"begginer"|"intermediate"|"advanced";
  createdAt: Date;
  updatedAt: Date;
}

const TopicSchema = new Schema<ITopic>(
  { 
    title:{
        type: String,
        required: [true, "عنوان الموضوع مطلوب"],
        trim: true,
        minlength: 2,
        maxlength: 100,
    },
    slug:{
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^[a-z0-9]+$/, "الرابط يحتوي فقط على ارقام حروف انجليزي صغيرة وارقام وشرطات فقط"],
    },
  subjectId:{
    type:Schema.Types.ObjectId,
    ref:"Subject",
    required:true,
},
videoURL:{
 type:String,
 default: "" ,
},
aiExplanation:{
    type:[String],
    default:[],
},
keyPoints:{
    type:[String],
    default:[]
},
vocabulary:[
    {
        word:{
            type:String,
            required:true,
        },
        definition:{
            type:String,
            required:true,
        }
    }
],
order:{
    type:Number,
    required:true,
    default:0
},
isFree:{
    type:Boolean,
    required:true,
    default:false,
},
isPublished:{
    type:Boolean,
    default:false,
},
difficulty:{
    type:String,
    enum:["beginner","intermediate","advanced"]
},
   },
  {
    timestamps: true, // adds createdAt + updatedAt automatically
  }
);
export const Topic = models.Topic || model<ITopic>("Topic", TopicSchema);
